export interface DividendRecord {
  id: string;
  date: string; // YYYY-MM-DD
  stockName: string;
  quantity: number;
  currentPrice: number;
  priceChange: number; // 주가등락
  dividendPerShare: number; // 분배금
  dividendChange: number; // 분배금등락
  taxBase: number; // 과세표준
  taxableDistribution: number; // 과세분배금
  taxAmount: number; // 과세금액
  // Calculated fields handled in logic usually, but useful to store if manual override
  // grossDistribution: number; // Quantity * DivPerShare
  // totalReceived: number; // Gross - Tax (or similar logic depending on account type)
}

export interface MonthlyStats {
  month: string;
  totalAmount: number;
}

export interface SummaryStats {
  totalTaxableDistribution: number; // 과세분배금총금액
  totalTaxAmount: number; // 과세 총 금액
  totalReceived: number; // 총 수령액
}
