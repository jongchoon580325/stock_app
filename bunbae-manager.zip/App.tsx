
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { DividendRecord, SummaryStats } from './types';
import { INITIAL_RECORDS } from './constants';
import { DividendTable } from './components/DividendTable';
import { StatsCards } from './components/StatsCards';
import { AnalysisSection } from './components/AnalysisSection';
import { DividendFormModal } from './components/DividendFormModal';
import { StockSummaryTable } from './components/StockSummaryTable';
import { NotificationModal } from './components/NotificationModal';
import { PlusCircle, LayoutDashboard, CalendarRange, ArrowRight, RotateCcw, Download, Upload, FileText } from 'lucide-react';

const STORAGE_KEY = 'bunbae_manager_data_v1';

const App: React.FC = () => {
  // Helper to recalculate derived fields (Rule 1, 2, 4, 5)
  // This ensures data consistency across the entire timeline
  const recalculatePortfolio = (rawRecords: DividendRecord[]): DividendRecord[] => {
    // 1. Sort by Date Ascending
    const sorted = [...rawRecords].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // Track last seen values for each stock to calculate changes
    const stockHistory: Record<string, { price: number; dividend: number }> = {};

    return sorted.map(record => {
      // Rule 4: Taxable Distribution = Tax Base * Quantity
      const taxableDistribution = record.taxBase * record.quantity;
      
      // Rule 5: Tax Amount = Taxable Distribution * 0.154 (Floor to integer for KRW)
      const taxAmount = Math.floor(taxableDistribution * 0.154);

      // Rule 1 & 2: Calculate Changes vs Previous Record of same stock
      let priceChange = 0;
      let dividendChange = 0;
      
      if (stockHistory[record.stockName]) {
        priceChange = record.currentPrice - stockHistory[record.stockName].price;
        dividendChange = record.dividendPerShare - stockHistory[record.stockName].dividend;
      }

      // Update history for next iteration
      stockHistory[record.stockName] = {
        price: record.currentPrice,
        dividend: record.dividendPerShare
      };

      return {
        ...record,
        taxableDistribution,
        taxAmount,
        priceChange,
        dividendChange
      };
    });
  };

  // Initialize state with LocalStorage or constants
  const [records, setRecords] = useState<DividendRecord[]>(() => {
    try {
        const savedData = localStorage.getItem(STORAGE_KEY);
        if (savedData) {
            const parsed = JSON.parse(savedData);
            return recalculatePortfolio(parsed);
        }
    } catch (e) {
        console.error("Failed to load local data", e);
    }
    return recalculatePortfolio(INITIAL_RECORDS);
  });

  // Save to LocalStorage whenever records change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  }, [records]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<DividendRecord | null>(null);
  
  // Notification Modal States
  const [resetWarningOpen, setResetWarningOpen] = useState(false);
  const [resetSuccessOpen, setResetSuccessOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Date Range Logic ---
  const availableMonths = useMemo(() => {
    const months = new Set(records.map(r => r.date.substring(0, 7))); // YYYY-MM
    return Array.from(months).sort();
  }, [records]);

  const [startMonth, setStartMonth] = useState<string>('');
  const [endMonth, setEndMonth] = useState<string>('');

  // Initialize default range when months are available
  // Updated dependency to ensure it runs when records change drastically (like import/reset)
  useEffect(() => {
    if (availableMonths.length > 0) {
      if (!startMonth || !availableMonths.includes(startMonth)) {
         setStartMonth(availableMonths[0]);
      }
      if (!endMonth || !availableMonths.includes(endMonth)) {
         setEndMonth(availableMonths[availableMonths.length - 1]);
      }
    }
  }, [availableMonths, startMonth, endMonth]); 

  // Filter records based on selection
  const filteredRecords = useMemo(() => {
    if (!startMonth || !endMonth) return records;
    return records.filter(r => {
      const m = r.date.substring(0, 7);
      return m >= startMonth && m <= endMonth;
    });
  }, [records, startMonth, endMonth]);

  // Calculate Summary Stats based on FILTERED records
  const summaryStats: SummaryStats = useMemo(() => {
    return filteredRecords.reduce((acc, curr) => {
      const gross = curr.quantity * curr.dividendPerShare;
      // Net = Gross - Tax
      const net = gross - curr.taxAmount;

      return {
        totalTaxableDistribution: acc.totalTaxableDistribution + curr.taxableDistribution,
        totalTaxAmount: acc.totalTaxAmount + curr.taxAmount,
        totalReceived: acc.totalReceived + net,
      };
    }, {
      totalTaxableDistribution: 0,
      totalTaxAmount: 0,
      totalReceived: 0
    });
  }, [filteredRecords]);

  // --- CRUD Handlers ---
  const openAddModal = () => {
    setEditingRecord(null);
    setIsModalOpen(true);
  };

  const openEditModal = (record: DividendRecord) => {
    setEditingRecord(record);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingRecord(null);
  };

  const handleSaveRecord = (record: DividendRecord) => {
    let updatedRecords;
    if (editingRecord) {
      updatedRecords = records.map(r => r.id === record.id ? record : r);
    } else {
      updatedRecords = [...records, record];
    }
    setRecords(recalculatePortfolio(updatedRecords));
    closeModal();
  };

  const handleDeleteRecord = (id: string) => {
    const remainingRecords = records.filter(r => r.id !== id);
    setRecords(recalculatePortfolio(remainingRecords));
    closeModal();
  };

  // --- Reset Logic ---
  const handleResetData = () => {
    setResetWarningOpen(true);
  };

  const executeReset = () => {
    // 1. Deep copy initial records to ensure no reference issues
    const freshRecords = JSON.parse(JSON.stringify(INITIAL_RECORDS));
    const processed = recalculatePortfolio(freshRecords);
    
    // 2. Set records
    setRecords(processed);

    // 3. FORCE update date filters immediately to match the new data range.
    // This prevents the "empty view" issue where filter is stuck on old dates.
    const newMonths = Array.from(new Set(processed.map((r: DividendRecord) => r.date.substring(0, 7)))).sort();
    if (newMonths.length > 0) {
        setStartMonth(newMonths[0]);
        setEndMonth(newMonths[newMonths.length - 1]);
    }

    setResetWarningOpen(false);
    setResetSuccessOpen(true);
  };

  // --- CSV Helpers ---
  
  // Format date safely to YYYY-MM-DD
  const formatDateForCSV = (dateStr: string) => {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  const convertToCSV = (data: DividendRecord[]) => {
    const headers = ['거래일', '종목명', '주식수량', '현주가', '분배금', '과세표준'];
    const rows = data.map(r => [
      formatDateForCSV(r.date), // Enforce YYYY-MM-DD
      r.stockName,
      r.quantity,
      r.currentPrice,
      r.dividendPerShare,
      r.taxBase
    ].join(','));
    return [headers.join(','), ...rows].join('\n');
  };

  const downloadCSV = (csvContent: string, fileName: string) => {
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // Add BOM for Excel
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 1. Download Sample (from INITIAL_RECORDS)
  const handleDownloadSample = () => {
    const csv = convertToCSV(INITIAL_RECORDS);
    downloadCSV(csv, '분배금_관리_샘플양식.csv');
  };

  // 2. Export Current Data
  const handleExportCSV = () => {
    const csv = convertToCSV(records);
    downloadCSV(csv, `분배금_현황_${new Date().toISOString().slice(0,10)}.csv`);
  };

  // Helper to normalize dates from Excel/CSV
  const normalizeImportDate = (dateStr: string) => {
    if (!dateStr) return new Date().toISOString().slice(0, 10);
    
    const cleanStr = dateStr.trim();

    // Handle DD/MM/YYYY (common in Excel CSV exports in some locales)
    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(cleanStr)) {
        const parts = cleanStr.split('/');
        // parts[0]=DD, parts[1]=MM, parts[2]=YYYY
        const yyyy = parts[2];
        const mm = parts[1].padStart(2, '0');
        const dd = parts[0].padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }
    
    // Handle YYYY/MM/DD
    if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(cleanStr)) {
        return cleanStr.replace(/\//g, '-');
    }

    // Handle YYYY.MM.DD (Common in Korea)
    if (/^\d{4}\.\s*\d{1,2}\.\s*\d{1,2}$/.test(cleanStr)) {
         const parts = cleanStr.split('.');
         const yyyy = parts[0].trim();
         const mm = parts[1].trim().padStart(2, '0');
         const dd = parts[2].trim().padStart(2, '0');
         return `${yyyy}-${mm}-${dd}`;
    }

    return cleanStr;
  };

  // 3. Import CSV
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      try {
        const lines = text.split('\n').map(l => l.trim()).filter(l => l);
        // Skip header
        const dataLines = lines.slice(1);
        
        const newRecords: DividendRecord[] = dataLines.map((line, idx) => {
          const cols = line.split(',');
          // Allow for empty trailing columns if CSV is sloppy
          if (cols.length < 6) throw new Error(`Line ${idx + 2} format invalid`);
          
          return {
            id: crypto.randomUUID(),
            date: normalizeImportDate(cols[0]),
            stockName: cols[1].trim(),
            quantity: Number(cols[2]),
            currentPrice: Number(cols[3]),
            dividendPerShare: Number(cols[4]),
            taxBase: Number(cols[5]),
            // Default calculated fields to 0, will be fixed by recalculatePortfolio
            priceChange: 0,
            dividendChange: 0,
            taxableDistribution: 0,
            taxAmount: 0
          };
        });

        if (confirm(`총 ${newRecords.length}건의 데이터를 불러왔습니다. 기존 데이터를 대체하시겠습니까?`)) {
            const processed = recalculatePortfolio(newRecords);
            setRecords(processed);
            
            // Also reset date filters for imported data
            const newMonths = Array.from(new Set(processed.map((r: DividendRecord) => r.date.substring(0, 7)))).sort();
            if (newMonths.length > 0) {
                setStartMonth(newMonths[0]);
                setEndMonth(newMonths[newMonths.length - 1]);
            }
        }
      } catch (err) {
        alert('CSV 파일 형식이 올바르지 않습니다. 샘플 양식을 참고해주세요.\n' + err);
        console.error(err);
      }
      // Reset input
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-100 pb-20">
      <DividendFormModal 
        isOpen={isModalOpen}
        onClose={closeModal}
        onSave={handleSaveRecord}
        onDelete={handleDeleteRecord}
        initialData={editingRecord}
      />

      <NotificationModal
        isOpen={resetWarningOpen}
        onClose={() => setResetWarningOpen(false)}
        type="warning"
        title="데이터 초기화"
        message={`현재 저장된 모든 데이터를 삭제하고\n기본 샘플 데이터로 복구하시겠습니까?`}
        onConfirm={executeReset}
        confirmLabel="네, 초기화합니다"
      />

      <NotificationModal
        isOpen={resetSuccessOpen}
        onClose={() => setResetSuccessOpen(false)}
        type="success"
        title="초기화 완료"
        message="데이터가 성공적으로 초기화되었습니다."
        confirmLabel="확인"
      />

      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-fuchsia-700" />
            <h1 className="text-xl font-bold text-slate-800 tracking-tight">일반배당계좌 분배금 현황</h1>
          </div>
          <div className="text-sm text-slate-500 hidden sm:block">
             ※ 일반계좌로 운영하는 분배금 내역을 요약하고 데이터를 관리합니다.
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        {/* Global Date Filter */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white p-4 rounded-lg shadow-sm border border-slate-200 gap-4">
            <div className="flex items-center gap-2 text-slate-700 font-bold">
                <CalendarRange className="w-5 h-5 text-indigo-600" />
                <span>조회 기간 설정</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
                <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-md border border-slate-200">
                    <span className="text-slate-500 text-xs font-semibold">시작월</span>
                    <select 
                        value={startMonth}
                        onChange={(e) => {
                            const newStart = e.target.value;
                            setStartMonth(newStart);
                            if (newStart > endMonth) setEndMonth(newStart);
                        }}
                        className="bg-transparent text-slate-800 font-medium focus:outline-none cursor-pointer"
                    >
                        {availableMonths.map(m => (
                            <option key={`start-${m}`} value={m}>{m}</option>
                        ))}
                    </select>
                </div>
                
                <ArrowRight className="w-4 h-4 text-slate-400" />
                
                <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-md border border-slate-200">
                    <span className="text-slate-500 text-xs font-semibold">종료월</span>
                    <select 
                        value={endMonth}
                        onChange={(e) => {
                            const newEnd = e.target.value;
                            setEndMonth(newEnd);
                            if (newEnd < startMonth) setStartMonth(newEnd);
                        }}
                        className="bg-transparent text-slate-800 font-medium focus:outline-none cursor-pointer"
                    >
                        {availableMonths.map(m => (
                            <option key={`end-${m}`} value={m}>{m}</option>
                        ))}
                    </select>
                </div>
            </div>
        </div>

        {/* Top Row: Summary Table & Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left: Stock Summary Table */}
            <div className="lg:col-span-2">
                <StockSummaryTable 
                    filteredRecords={filteredRecords} 
                    startMonth={startMonth}
                    endMonth={endMonth}
                />
            </div>

            {/* Right: Stats & AI */}
            <div className="flex flex-col gap-6">
                <StatsCards stats={summaryStats} />
                <AnalysisSection records={filteredRecords} />
            </div>
        </div>

        {/* Action Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-2 border-t border-slate-200 mt-8 pt-6 gap-4">
            <div className="flex flex-col w-full md:w-auto">
              <h2 className="text-lg font-bold text-slate-800">상세 내역 관리</h2>
              <span className="text-xs text-slate-500">CSV 파일을 통해 대량의 데이터를 관리하거나 백업할 수 있습니다.</span>
            </div>
            
            <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end">
                {/* Hidden File Input */}
                <input 
                    type="file" 
                    accept=".csv" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    className="hidden" 
                />

                <button 
                    onClick={handleDownloadSample}
                    className="flex items-center gap-2 px-3 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 text-sm font-medium rounded-md hover:bg-emerald-100 transition-colors"
                    title="입력 서식 다운로드"
                >
                    <FileText className="w-4 h-4" />
                    샘플 양식
                </button>

                 <div className="h-8 w-px bg-slate-300 mx-1 hidden md:block"></div>

                <button 
                    onClick={handleExportCSV}
                    className="flex items-center gap-2 px-3 py-2 bg-white text-slate-600 border border-slate-300 text-sm font-medium rounded-md hover:bg-slate-50 transition-colors"
                >
                    <Download className="w-4 h-4" />
                    내보내기
                </button>
                <button 
                    onClick={handleImportClick}
                    className="flex items-center gap-2 px-3 py-2 bg-white text-slate-600 border border-slate-300 text-sm font-medium rounded-md hover:bg-slate-50 transition-colors"
                >
                    <Upload className="w-4 h-4" />
                    가져오기
                </button>

                <div className="h-8 w-px bg-slate-300 mx-1 hidden md:block"></div>

                <button 
                    onClick={handleResetData}
                    className="flex items-center gap-2 px-3 py-2 bg-red-50 text-red-600 border border-red-200 text-sm font-medium rounded-md hover:bg-red-100 transition-colors"
                    title="초기 데이터로 복원"
                >
                    <RotateCcw className="w-4 h-4" />
                    초기화
                </button>
                
                <button 
                    onClick={openAddModal}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white text-sm font-medium rounded-md hover:bg-slate-700 transition-colors shadow-sm ml-2"
                >
                    <PlusCircle className="w-4 h-4" />
                    데이터 등록
                </button>
            </div>
        </div>

        <DividendTable 
          records={records} 
          onRowClick={openEditModal} 
        />

      </main>
    </div>
  );
};

export default App;
